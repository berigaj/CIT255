﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame.Model
{
   public class HistoricScore
    {
        public string PlayerXName { get; set; }
        public int PlayerXScore { get; set; }

        public string PlayeOName { get; set; }
        public int PlayerOScore { get; set; }
    }
}
