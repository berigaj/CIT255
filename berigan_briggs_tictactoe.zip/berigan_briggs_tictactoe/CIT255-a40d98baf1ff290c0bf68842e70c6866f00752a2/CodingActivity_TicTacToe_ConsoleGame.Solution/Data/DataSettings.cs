﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingActivity_TicTacToe_ConsoleGame.Data
{
    public class DataSettings
    {
        public const string DataFilePath = "Data\\HistoricGameStats.txt";
        public const char Delineator = ',';
    }
}
